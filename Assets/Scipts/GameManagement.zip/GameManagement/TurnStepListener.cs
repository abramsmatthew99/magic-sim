using System;
using System.Collections.Generic;
using UnityEngine;

public class ListenerObject : MonoBehaviour
{
    private StepManager stepManager;

    private void Start()
    {
        stepManager = FindObjectOfType<StepManager>();
        stepManager.OnStepChanged += OnStepChanged;
    }

    private void OnDestroy()
    {
        stepManager.OnStepChanged -= OnStepChanged;
    }

    private void OnStepChanged(TurnStep newStep)
    {
        foreach (var componentType in newStep.componentTypes)
        {
            Type type = Type.GetType(componentType);
            if (type != null)
            {
                var component = gameObject.AddComponent(type) as MonoBehaviour;
                (component as dynamic)?.Execute();
                Destroy(component); // Optionally destroy component after execution
            }
        }
    }
}
